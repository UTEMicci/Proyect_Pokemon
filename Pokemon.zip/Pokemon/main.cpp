#include <iostream>
#include "Poke.h"
#include <string.h>
#include <string>
#include <fstream>
#include <sstream>

// NOMBRE;NIVEL;VIDA;ATAQUE 1; 2; 3; 4; 5; 6;ATAQUE;DEFENSA;RESISTENCIA
using namespace std;


int main()
{

    menu();



}
