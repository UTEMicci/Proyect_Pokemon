#include "Poke.h"
#include <iostream>
#include <string.h>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <ctype.h>
using namespace std;
// NOMBRE;NIVEL;VIDA;ATAQUE 1; 2; 3; 4; 5; 6;ATAQUE;DEFENSA;RESISTENCIA LEO
// NOMBRE;NIVEL;VIDA;ATAQUE;DEFENSA;
Poke::Poke()
{
    nombre="SIN NOMBRE";
    vida=0;
    ataque1="SIN ATAQUE 1";
    poder1=0;
    ataque2="SIN ATAQUE 2";
    poder2=0;

    ataque3="SIN ATAQUE 3";
    poder3=0;

    ataque4="SIN ATAQUE 4";
    poder4=0;

    atac=0;
    defensa=0;
    nivel=0;

}
Poke::~Poke()
{
    //dtor
}
//SETTERS
void Poke::setnombre(string _nombre)
{
    nombre=_nombre;
}
void Poke::setnivel(int _nivel)
{
    nivel=_nivel;
}
void Poke::setvida(int _vida)
{
    vida=_vida;
}

void Poke::setataque1(string ataque)
{
    ataque1=ataque;
}
void Poke::setataque2(string ataque)
{
    ataque2=ataque;
}
void Poke::setataque3(string ataque)
{
    ataque3=ataque;
}
void Poke::setataque4(string ataque)
{
    ataque4=ataque;
}
void Poke::setpoder1(int poder)
{
    poder1=poder;
}
void Poke::setpoder2(int poder)
{
    poder2=poder;
}
void Poke::setpoder3(int poder)
{
    poder3=poder;
}
void Poke::setpoder4(int poder)
{
    poder4=poder;
}
void Poke::setatac(int _atac)
{
    atac=_atac;
}
void Poke::setdefensa(int _defensa)
{
    defensa=_defensa;
}

//GETTERS
string Poke::getnombre()
{
    return nombre;
}
int Poke::getnivel()
{
    return nivel;
}
int Poke::getvida()
{
    return vida;
}
string Poke::getataque1()
{
    return ataque1;
}
string Poke::getataque2()
{
    return ataque2;
}
string Poke::getataque3()
{
    return ataque3;
}
string Poke::getataque4()
{
    return ataque4;
}
int Poke::getpoder1()
{
    return poder1;
}
int Poke::getpoder2()
{
    return poder2;
}
int Poke::getpoder3()
{
    return poder3;
}
int Poke::getpoder4()
{
    return poder4;
}
int Poke::getatac()
{
    return atac;
}
int Poke::getdefensa()
{
    return defensa;
}

void Poke::VER()
{
    cout << "Nombre del Pokemon: " << nombre << endl;
    cout << "Vida del Pokemon: " << vida << endl;
    cout << "Nivel del Pokemon: " << nivel << endl;
    cout << "Ataque 1 del Pokemon y su poder 1 : " <<ataque1 << " , " << poder1 << endl;
    cout << "Ataque 2 del Pokemon y su poder 2 : " <<ataque2 << " , " << poder2 << endl;
    cout << "Ataque 3 del Pokemon y su poder 3 : " <<ataque3 << " , " << poder3 << endl;
    cout << "Ataque 4 del Pokemon y su poder 4 : " <<ataque4 << " , " << poder4 << endl;
    cout << "Ataque Base del Pokemon : " << atac << endl;
    cout << "Defensa Base del Pokemon : " << defensa << endl;
}
void SEPARAR(string txt,Poke P[],ATAQUES &A,int &cont)
{
    stringstream sep(txt);
    int i=0;
    while (getline(sep,txt,';')){
        if (i==0)
            P[cont].setnombre(txt);
        if (i==1)
            P[cont].setnivel(atoi(txt.c_str()));
        if (i==2)
            P[cont].setvida(atoi(txt.c_str()));
        if (i==3)
            P[cont].setatac(atoi(txt.c_str()));
        if (i==4)
            P[cont].setdefensa(atoi(txt.c_str()));
        if (i==5)
            A[cont].ATA1=txt;
        if (i==6)
            A[cont].POT1=atoi(txt.c_str());
        if (i==7)
            A[cont].ATA2=txt;
        if (i==8)
            A[cont].POT2=atoi(txt.c_str());
        if (i==9)
            A[cont].ATA3=txt;
        if (i==10)
            A[cont].POT3=atoi(txt.c_str());
        if (i==11)
            A[cont].ATA4=txt;
        if (i==12)
            A[cont].POT4=atoi(txt.c_str());
        if (i==13)
            A[cont].ATA5=txt;
        if (i==14)
            A[cont].POT5=atoi(txt.c_str());
        if (i==15)
            A[cont].ATA6=txt;
        if (i==16)
            A[cont].POT6=atoi(txt.c_str());

        i++;
    }
    cont=cont+1;
}


/*
void SelAttac(ATAQUE A,Poke P)
{
    int cont=1;
    while (cont<5){
        for (int i=1;i<7;i++){
            cout << "ELECCION DE ATAQUE " << i << ":" <<endl;
            cout << "Se muestran los ataques disponibles: " << endl;
            cout << "ATAQUE 1" << A.ATA1 << "con potencia:  " << A.POT1 << endl;
            cout << "Si deseas este ataque, presionar ---> 1" << endl;
            cout << "ATAQUE 2" << A.ATA2 << "con potencia:  " << A.POT2 << endl;
            cout << "Si deseas este ataque, presionar ---> 2" << endl;
            cout << "ATAQUE 3" << A.ATA3 << "con potencia:  "<< A.POT3<< endl;
            cout << "Si deseas este ataque, presionar ---> 3"<< endl;
            cout << "ATAQUE 4" << A.ATA4 << "con potencia:  "<< A.POT4<< endl;
            cout << "Si deseas este ataque, presionar ---> 4 "<< endl;
            cout << "ATAQUE 5" << A.ATA5 << "con potencia:  "<< A.POT5<< endl;
            cout << "Si deseas este ataque, presionar ---> 5"<< endl;
            cout << "ATAQUE 6" << A.ATA6 << "con potencia:  "<< A.POT6<< endl;
            cout << "Si deseas este ataque, presionar ---> 6"<< endl;
            int opc;
            cin >> opc;
            if (opc==1){
                P.setataque1(A.ATA1);
                P.setpoder[i](A.POT1);
                cont++;
            }
            if (opc==2){
                P.setataque[i](A.ATA2);
                P.setpoder[i](A.POT2);
                cont++;
            }
            if (opc==3){
                P.setataque[i](A.ATA3);
                P.setpoder[i](A.POT3);
                cont++;
            }
            if (opc==4){
                P.setataque[i](A.ATA4);
                P.setpoder[i](A.POT4);
                cont++;
            }
            if (opc==5){
                P.setataque[i](A.ATA5);
                P.setpoder[i](A.POT5);
                cont++;
            }
            if (opc==6){
                P.setataque[i](A.ATA6);
                P.setpoder[i](A.POT6);
                cont++;
            }
        }
    }


}

*/

void Mochila(Poke p1, Poke p2, Poke p3, Poke p4, Poke mochila[])
{
    mochila[1]=p1;
    mochila[2]=p2;
    mochila[3]=p3;
    mochila[4]=p4;

}

void menu()
{
    Poke P[200];
    Poke mochila1[5];
    Poke mochila2[5];
    ATAQUE A[200];
    //P.VER();
    int cont=0;
    ifstream archivo;
    string texto;
    archivo.open("PokeDex.txt",ios::in);
    if (archivo.fail())
        cout <<"error";
    while (getline (archivo,texto)){
        stringstream Separacion (texto);
        while (getline (Separacion,texto,'\n')){
            SEPARAR(texto,P,A,cont);
       }
    }
    int opc,men=1;
    //Poke P1,P2;

    system("cls");
    do{
        cout <<"ingrese opc " << endl;
        cout << "1 : eleccion de pokemon's(4) para player 1" << endl;
        cout << "2 : eleccion de pokemon's(4) para player 2" << endl;
        cout << "3 : acabar" << endl;
        cin >> opc;
        if (opc ==1 || opc ==2 || opc ==3){
            if (opc==1){
                //cout << "ALEATORIO O MANUAL? " << endl;
                //cout << "1, manual " << endl;
                //cout << "2, aleatorio " << endl;
                //int resp;
                //cin >> resp;
                //if (resp==1){
                    Poke p1,p2,p3,p4;
                    string n1,n2,n3,n4;
                    cout << "Ingrese el nombre del 1er Pokemon" << endl;
                    cin >> n1;
                    p1=p1.ElegirPokemon(P,p1,n1);
                    cout << "Ingrese el nombre del 2do Pokemon " << endl;
                    cin >> n2;
                    p2=p2.ElegirPokemon(P,p2,n2);
                    cout << "Ingrese el nombre del 3er Pokemon" << endl;
                    cin >> n3;
                    p3=p3.ElegirPokemon(P,p3,n3);
                    cout << "Ingrese el nombre del 4do Pokemon " << endl;
                    cin >> n4;
                    p4=p4.ElegirPokemon(P,p4,n4);
                    Mochila(p1,p2,p3,p4,mochila1);
            //}
            }
            if (opc==2){
                //cout << "ALEATORIO O MANUAL? " << endl;
                //cout << "1, manual " << endl;
                //cout << "2, aleatorio " << endl;
                //int resp;
                //cin >> resp;
                //if (resp==1){
                    Poke p1,p2,p3,p4;
                    string n1,n2,n3,n4;
                    cout << "Ingrese el nombre del 1er Pokemon" << endl;
                    cin >> n1;
                    p1=p1.ElegirPokemon(P,p1,n1);
                    cout << "Ingrese el nombre del 2do Pokemon " << endl;
                    cin >> n2;
                    p2=p2.ElegirPokemon(P,p2,n2);
                    cout << "Ingrese el nombre del 3er Pokemon" << endl;
                    cin >> n3;
                    p3=p3.ElegirPokemon(P,p3,n3);
                    cout << "Ingrese el nombre del 4do Pokemon " << endl;
                    cin >> n4;
                    p4=p4.ElegirPokemon(P,p4,n4);
                    Mochila(p1,p2,p3,p4,mochila2);
                //}

            }
            if (opc==3)
                men=0;
        }
        else{
            cout << "opcion no valida" << endl;
        }
    }
    while(men==1);

    //cout <<"POKEMON 1:" <<mochila1[1].getnombre() << endl;
    //cout <<"POKEMON 2:" <<mochila1[2].getnombre() << endl;
    //cout <<"POKEMON 3:" <<mochila1[3].getnombre() << endl;
    //cout <<"POKEMON 4:" <<mochila1[4].getnombre() << endl;
}

Poke Poke::ElegirPokemon(Poke A[], Poke E, string Pokemon){ // ELEGIR POKEMON SE REALIZA COMPARANDO EL NOMBRE INGRESADO POR TECLADO Y EL NOMBRE DEL POKEMON, AMBOS STRING SON PASADOS A MINUSCULAS Y SE COMPARA SI SON IGUALES
    for (int i=0; i<300;i++)
    {   minuscula(Pokemon);
        string aux;
        aux=A[i].nombre;
        minuscula(aux);
        if (Pokemon==aux){
            E=A[i];
            return E;
        }

    }
}
void minuscula(string &a)
{
    for  (int i=0;i<a.length();i++)
    {
        a[i]=tolower(a[i]);
    }
}
