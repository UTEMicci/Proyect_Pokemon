#ifndef POKE_H
#define POKE_H
#include <iostream>
#include <string.h>
// NOMBRE;NIVEL;VIDA;ATAQUE 1; 2; 3; 4; 5; 6;ATAQUE;DEFENSA
using namespace std;
typedef struct ATAQUE{
    string ATA1;
    string ATA2;
    string ATA3;
    string ATA4;
    string ATA5;
    string ATA6;
    int POT1;
    int POT2;
    int POT3;
    int POT4;
    int POT5;
    int POT6;
}ATAQUES[200];

class Poke
{
    public:
        Poke();
        virtual ~Poke();
        //SETTERS
        void setnombre(string);
        void setnivel(int);
        void setvida(int);
        void setataque1(string);
        void setpoder1(int);
        void setataque2(string);
        void setpoder2(int);
        void setataque3(string);
        void setpoder3(int);
        void setataque4(string);
        void setpoder4(int);
        void setatac(int);
        void setdefensa(int);
        //GETTERS
        string getnombre();
        int getnivel();
        string getataque1();
        int getpoder1();
        string getataque2();
        int getpoder2();
        string getataque3();
        int getpoder3();
        string getataque4();
        int getpoder4();
        int getvida();
        int getatac();
        int getdefensa();
        //FUNCIONES
        void VER();
        void Player1(Poke);
        void Player2(Poke);
        Poke ElegirPokemon(Poke[],Poke,string);
    private:
        string nombre;
        int nivel;
        int vida;
        string ataque1;
        int poder1;
        string ataque2;
        int poder2;
        string ataque3;
        int poder3;
        string ataque4;
        int poder4;
        int atac;
        int defensa;
};
void menu();
void SEPARAR(string, Poke[], ATAQUES&, int&);
void minuscula(string&);
void Mochila(Poke, Poke, Poke, Poke, Poke[]);
//void elegir ()
//void SelAttac(ATAQUE,Poke)
#endif // POKE_H
